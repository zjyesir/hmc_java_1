package abstractPackage;

/**
 * 类似 toString 功能，打印这个类的信息
 * @author ianye
 *
 */
public interface DemoClassInfo {
	void demoClassInfo();
}
